package com.voltrace.client.core.rendering;
import org.lwjgl.opengl.*;
/** LOD digambar dulu ke FBO sendiri (depth sendiri, far plane besar), lalu dikomposit ke framebuffer aktif HANYA di piksel yang belum digambar apa pun
 *  (kedalaman scene == nilai clear, yaitu langit/area kosong). Konsekuensinya terrain, entity, block entity, player, dan translucent vanilla tidak pernah tertimpa,
 *  dan depth scene tidak diubah. Tidak bergantung pada konvensi depth (reverse-Z dll) karena hanya membandingkan dengan nilai clear.
 *  mode 0: tes depth hardware GL_EQUAL (vanilla). mode 1: mask dari salinan depth (shader pack: depth diambil di BEFORE_TRANSLUCENT, sebelum composite Iris). */
public final class LodTarget {
  private int fbo, col, dep, w, h, prog, vao, sceneDep, sw, sh; private boolean sceneValid;
  private static int tex(int w, int h, int fmt, int format, int type) {
    int t = GL11.glGenTextures(); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
    GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, fmt, w, h, 0, format, type, 0L); return t;
  }
  /** Apakah framebuffer tujuan punya attachment depth (tanpa itu tes depth hardware tidak bermakna dan LOD tidak boleh digambar). */
  public static boolean hasDepth() {
    if (GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING) == 0) return true;
    return GL30.glGetFramebufferAttachmentParameteri(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE) != GL11.GL_NONE;
  }
  public void ensure(int W, int H) {
    if (fbo != 0 && W == w && H == h) return;
    int prevT = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), prevF = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
    if (fbo != 0) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(col); GL11.glDeleteTextures(dep); }
    w = W; h = H; col = tex(w, h, GL11.GL_RGBA8, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE); dep = tex(w, h, GL14.GL_DEPTH_COMPONENT24, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT);
    fbo = GL30.glGenFramebuffers(); GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, col, 0);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, dep, 0);
    int st = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevF); GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevT);
    if (st != GL30.GL_FRAMEBUFFER_COMPLETE) throw new IllegalStateException("FBO LOD tidak lengkap: " + st);
    if (prog == 0) { prog = Shaders.program(Shaders.src("post/composite.vert"), Shaders.src("post/composite.frag")); vao = GL30.glGenVertexArrays(); }
  }
  /** Salin depth framebuffer yang sedang aktif (depth scene sebelum translucent / sebelum composite shader pack) ke tekstur sendiri. */
  public void captureScene(int x, int y, int W, int H) {
    int prevT = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), prevRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING), draw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
    if (sceneDep == 0 || sw != W || sh != H) { if (sceneDep != 0) GL11.glDeleteTextures(sceneDep); sceneDep = tex(W, H, GL14.GL_DEPTH_COMPONENT24, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT); sw = W; sh = H; }
    else GL11.glBindTexture(GL11.GL_TEXTURE_2D, sceneDep);
    GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, draw);
    for (int i = 0; i < 8 && GL11.glGetError() != 0; i++) {}
    GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, x, y, W, H);
    sceneValid = GL11.glGetError() == 0;
    GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead); GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevT);
  }
  public boolean sceneReady(int W, int H) { return sceneValid && sw == W && sh == H; }
  public void begin() { GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo); GL11.glClearColor(0f, 0f, 0f, 0f); GL11.glClearDepth(1.0); GL11.glDepthMask(true); GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT); }
  /** clr = nilai clear depth framebuffer tujuan. GlSnapshot.restore() memulihkan semua state setelahnya. */
  public void end(int prevFbo, int mode, float clr) {
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevFbo);
    // FBO tujuan bisa punya banyak attachment (G-buffer); komposit hanya menulis 1 output, jadi attachment lain dimatikan sementara.
    if (prevFbo != 0) GL20.glDrawBuffers(GL30.GL_COLOR_ATTACHMENT0);
    GL11.glColorMask(true, true, true, true); GL11.glDepthMask(false); GL11.glDisable(GL11.GL_BLEND); GL11.glDisable(GL11.GL_CULL_FACE);
    if (mode == 0) { GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_EQUAL); } else GL11.glDisable(GL11.GL_DEPTH_TEST);
    int unit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
    GL13.glActiveTexture(GL13.GL_TEXTURE2); int t2 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D); if (mode == 1) GL11.glBindTexture(GL11.GL_TEXTURE_2D, sceneDep);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); int t0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D); GL11.glBindTexture(GL11.GL_TEXTURE_2D, col);
    GL20.glUseProgram(prog); GL20.glUniform1i(GL20.glGetUniformLocation(prog, "uCol"), 0); GL20.glUniform1i(GL20.glGetUniformLocation(prog, "uScn"), 2);
    GL20.glUniform1f(GL20.glGetUniformLocation(prog, "uMode"), mode); GL20.glUniform1f(GL20.glGetUniformLocation(prog, "uClr"), clr);
    GL30.glBindVertexArray(vao); GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t0); GL13.glActiveTexture(GL13.GL_TEXTURE2); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t2); GL13.glActiveTexture(unit);
    sceneValid = false;
  }
}
