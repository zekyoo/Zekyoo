package com.voltrace.client.core;
import com.voltrace.client.VolTraceClient; import com.voltrace.client.compat.GpuInfo; import com.voltrace.client.config.VolConfig;
import com.voltrace.client.core.model.LodColors; import com.voltrace.client.core.model.TileAtlas; import com.voltrace.client.core.rendering.*; import com.voltrace.client.iris.IrisCompat;
import com.voltrace.common.voxelization.Mesher; import com.voltrace.common.world.*; import com.voltrace.common.world.LodOctree.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.world.ClientWorld; import net.minecraft.registry.RegistryKey; import net.minecraft.world.World; import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4d; import org.joml.Matrix4f; import org.joml.Quaternionf; import org.joml.Vector3d; import org.lwjgl.opengl.*;
import java.nio.file.Files; import java.nio.file.Path; import java.util.*; import java.util.concurrent.*; import java.util.concurrent.atomic.*;
/** Pusat koordinasi: ingest chunk -> sintesis terrain jauh -> pilih section terlihat per ring LOD -> bangun mesh di worker -> upload & gambar di thread render. */
public final class LodManager {
  static final double RING = 768.0; // level L menutup jarak [RING*2^(L-1), RING*2^L): L0 detail 1 blok sampai 48 chunk, lalu 2,4,8,... blok
  static volatile LodOctree tree; static ClientWorld curWorld; static volatile RegistryKey<World> curDim; static RenderBackend backend; static LodTarget target; static ShadowMap shadow;
  static final ConcurrentHashMap<Key, Integer> uploaded = new ConcurrentHashMap<>();
  static final Set<Key> building = ConcurrentHashMap.newKeySet();
  static final ConcurrentLinkedQueue<Built> ready = new ConcurrentLinkedQueue<>();
  static final ConcurrentLinkedQueue<Key> removeQ = new ConcurrentLinkedQueue<>();
  static final Set<CK> synthing = ConcurrentHashMap.newKeySet(); static final AtomicInteger synthFlight = new AtomicInteger(); static final Set<String> warned = ConcurrentHashMap.newKeySet();
  static volatile List<Key> visible = List.of(); static volatile double camX, camY, camZ, vanillaB = 192; static volatile long postStamp;
  static final AtomicBoolean updating = new AtomicBoolean(); static int tickN; static long lastSave = System.currentTimeMillis(), lastDiag;
  static final ThreadPoolExecutor exec = new ThreadPoolExecutor(Math.max(1, VolConfig.buildThreads), Math.max(1, VolConfig.buildThreads), 30L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(),
    r -> { Thread t = new Thread(r, "voltrace-worker"); t.setDaemon(true); t.setPriority(Thread.NORM_PRIORITY - 1); return t; });
  record Built(LodOctree t, Key key, int[] mesh, int ver) {}
  record Cand(CK ck, double d) {}

  /** Jumlah thread diubah langsung dari menu (mode kompatibilitas membatasi ke 2). */
  public static void applyThreads() {
    int n = Math.max(1, GpuInfo.lowEnd() ? Math.min(2, VolConfig.buildThreads) : VolConfig.buildThreads);
    if (n > exec.getMaximumPoolSize()) { exec.setMaximumPoolSize(n); exec.setCorePoolSize(n); } else { exec.setCorePoolSize(n); exec.setMaximumPoolSize(n); }
  }
  static void warnOnce(String key, String msg) { if (warned.add(key)) VolTraceClient.LOGGER.warn(msg); }

  // ---------- dunia ----------
  static void ensureWorld(MinecraftClient mc) {
    ClientWorld w = mc.world; if (w == curWorld) return;
    closeWorld(); curWorld = w; if (w == null) return;
    String base = mc.isInSingleplayer() && mc.getServer() != null ? "sp_" + mc.getServer().getSaveProperties().getLevelName()
      : "mp_" + (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "unknown");
    String id = (base + "__" + w.getRegistryKey().getValue()).replaceAll("[^A-Za-z0-9._-]", "_");
    Path root = FabricLoader.getInstance().getGameDir().resolve("voltrace"), old = FabricLoader.getInstance().getGameDir().resolve("noxring");
    try { if (!Files.exists(root) && Files.isDirectory(old)) Files.move(old, root); } catch (Exception e) { VolTraceClient.LOGGER.warn("migrasi data lama gagal: {}", e.toString()); }   // data NoxRing -> VolTrace
    Path dir = root.resolve(id); curDim = w.getRegistryKey(); synthing.clear();
    tree = new LodOctree(dir); TileAtlas.open(dir); LodColors.reload(mc); uploaded.clear(); building.clear(); ready.clear(); removeQ.clear(); visible = List.of();
    if (backend != null) backend.clear();
  }
  static void closeWorld() { LodOctree t = tree; tree = null; if (t != null) t.saveAll(); }
  public static void shutdown() { closeWorld(); VolConfig.save(); }
  /** Muat ulang tekstur blok dari resource pack aktif (/voltrace reload). */
  public static void reloadTextures() { TileAtlas.reopen(); LodColors.reload(MinecraftClient.getInstance()); }

  public static void onChunk(WorldChunk chunk) {
    MinecraftClient mc = MinecraftClient.getInstance(); ensureWorld(mc);
    LodOctree t = tree; if (t == null || !VolConfig.enabled || !VolConfig.ingest) return;
    exec.execute(() -> { try { ChunkIngest.run(t, chunk); } catch (Throwable e) { VolTraceClient.LOGGER.warn("ingest gagal: {}", e.toString()); } });
  }
  public static void tick(MinecraftClient mc) {
    ensureWorld(mc); if (tree == null || !VolConfig.enabled) return;
    LodGenerator.tick(mc, tree);
    if (++tickN % 5 == 0 && updating.compareAndSet(false, true)) exec.execute(() -> { try { update(); } catch (Throwable e) { e.printStackTrace(); } finally { updating.set(false); } });
  }

  // ---------- pemilihan section + sintesis + build mesh (worker) ----------
  static void update() {
    LodOctree t = tree; RenderBackend be = backend; if (t == null || be == null) return;
    long now = System.currentTimeMillis(); if (now - lastSave > 30000) { lastSave = now; t.evict(VolConfig.memoryMb * 1024L * 1024L); t.saveDirty(); }
    double cx = camX, cz = camZ, vb = vanillaB, maxB = VolConfig.renderChunks * 16.0; List<Key> vis = new ArrayList<>(); List<Cand> cand = new ArrayList<>();
    boolean synthOn = VolConfig.synth && MinecraftClient.getInstance().getServer() != null;
    for (int L = 0; L <= LodOctree.MAX_LEVEL; L++) {
      double lo = L == 0 ? 0 : RING * (1L << (L - 1)), hi = Math.min(RING * (double) (1L << L), maxB); if (lo >= maxB) break;
      int size = 32 << L, x0 = Math.floorDiv((int) (cx - hi - size), size), x1 = Math.floorDiv((int) (cx + hi + size), size), z0 = Math.floorDiv((int) (cz - hi - size), size), z1 = Math.floorDiv((int) (cz + hi + size), size);
      for (int sx = x0; sx <= x1; sx++) for (int sz = z0; sz <= z1; sz++) {
        double d = Math.hypot(sx * (double) size + size / 2.0 - cx, sz * (double) size + size / 2.0 - cz);
        if (d < lo || d >= hi || (L == 0 && d + size * 0.71 < vb)) continue;
        CK ck = new CK(L, sx, sz);
        if (synthOn && !t.isSynth(ck) && !synthing.contains(ck)) cand.add(new Cand(ck, d));
        Column col = t.column(ck, false); if (col == null) continue;
        for (var e : col.secs.entrySet()) if (!e.getValue().isEmpty()) vis.add(new Key(L, sx, e.getKey(), sz));
      }
    }
    visible = be.wantsMeshes() ? vis : List.of();
    if (be.wantsMeshes()) {
      Set<Key> vs = new HashSet<>(vis); List<Key> need = new ArrayList<>();
      for (Key k : vis) { Section s = t.get(k); Integer up = uploaded.get(k); if (s != null && !building.contains(k) && (up == null || up != s.version)) need.add(k); }
      need.sort(Comparator.comparingDouble(k -> { double sz = 32.0 * (1L << k.level()); return Math.hypot(k.sx() * sz - cx, k.sz() * sz - cz); }));
      for (Key k : need) { if (building.size() >= 64) break; if (building.add(k)) exec.execute(() -> build(t, k)); }
      for (Key k : uploaded.keySet()) if (!vs.contains(k)) removeQ.add(k);
    }
    if (!cand.isEmpty()) requestSynth(t, cand);
  }
  /** Sintesis terrain jauh: terdekat dulu, maksimal sebanyak thread worker yang berjalan bersamaan. */
  static void requestSynth(LodOctree t, List<Cand> cand) {
    cand.sort(Comparator.comparingDouble(Cand::d)); int limit = Math.max(1, VolConfig.buildThreads);
    for (Cand c : cand) {
      if (synthFlight.get() >= limit) break; if (!synthing.add(c.ck())) continue; synthFlight.incrementAndGet();
      exec.execute(() -> { try { TerrainSynth.run(t, c.ck()); } catch (Throwable e) { VolTraceClient.LOGGER.warn("sintesis terrain gagal: {}", e.toString()); t.markSynth(c.ck()); } finally { synthing.remove(c.ck()); synthFlight.decrementAndGet(); } });
    }
  }
  static void build(LodOctree t, Key k) {
    try { Section s = t.get(k); if (s == null) return; int ver = s.version; ready.add(new Built(t, k, Mesher.mesh(t, k), ver)); }
    catch (Throwable e) { e.printStackTrace(); } finally { building.remove(k); }
  }

  // ---------- jalur render ----------
  static boolean usePost() { String m = VolConfig.shaderMode; if (m.equals("legacy")) return false; if (m.equals("post")) return true; return IrisCompat.packActive(); }
  /** Event Fabric BEFORE_TRANSLUCENT. Tanpa shader: LOD digambar di sini. Shader pack aktif: hanya menyalin depth scene (LOD digambar setelah Iris selesai). */
  public static void renderLegacy() {
    if (usePost() && System.currentTimeMillis() - postStamp < 1500) { captureScene(); return; }
    render(false);
  }
  /** Dipanggil mixin setelah Iris selesai menjalankan composite + final pass. */
  public static void renderPost() { postStamp = System.currentTimeMillis(); if (usePost()) render(true); }
  static void captureScene() {
    MinecraftClient mc = MinecraftClient.getInstance(); if (tree == null || !VolConfig.enabled || mc.world == null) return;
    try {
      int[] vpt = new int[4]; GL11.glGetIntegerv(GL11.GL_VIEWPORT, vpt); if (vpt[2] <= 0 || vpt[3] <= 0) return;
      if (target == null) target = new LodTarget(); target.captureScene(vpt[0], vpt[1], vpt[2], vpt[3]);
    } catch (Throwable e) { warnOnce("capture", "salin depth scene gagal: " + e); }
  }

  /** LOD -> FBO sendiri -> komposit ke framebuffer aktif hanya di piksel kosong. post=true: dipanggil setelah Iris. */
  static void render(boolean post) {
    LodOctree t = tree; MinecraftClient mc = MinecraftClient.getInstance();
    if (t == null || !VolConfig.enabled || mc.world == null) return;
    GpuInfo.init(); GlSnapshot snap = new GlSnapshot(); snap.prepare();
    try {
      var camera = mc.gameRenderer.getCamera(); var cp = camera.getCameraPos(); camX = cp.x; camY = cp.y; camZ = cp.z;
      vanillaB = mc.options.getClampedViewDistance() * 16.0; boolean low = GpuInfo.lowEnd();
      if (backend == null) { backend = BackendSelector.select(); backend.init(); applyThreads(); VolTraceClient.LOGGER.info("backend: {}", backend.name()); }
      if (target == null) target = new LodTarget(); if (shadow == null) shadow = new ShadowMap();
      int budget = low ? Math.min(3, VolConfig.uploadsPerFrame) : VolConfig.uploadsPerFrame; Built b;
      while (budget > 0 && (b = ready.poll()) != null) { if (b.t() != t) continue; backend.upload(b.key(), b.mesh()); uploaded.put(b.key(), b.ver()); budget--; }
      Key rk; while ((rk = removeQ.poll()) != null) { backend.remove(rk); uploaded.remove(rk); }
      int[] vpt = new int[4]; GL11.glGetIntegerv(GL11.GL_VIEWPORT, vpt); if (vpt[2] <= 0 || vpt[3] <= 0) return;
      int fbo = snap.drawFbo(); float clr = snap.clearDepth();
      int mode = post ? (target.sceneReady(vpt[2], vpt[3]) ? 1 : -1) : (LodTarget.hasDepth() ? 0 : -1);
      if (mode < 0) { warnOnce("nodepth" + post, "VolTrace: depth scene tidak tersedia (" + (post ? "salinan depth gagal" : "FBO tanpa depth") + "), LOD tidak digambar agar tidak menimpa terrain/entity vanilla"); return; }

      float aspect = (float) vpt[2] / vpt[3], fovY = (float) Math.toRadians(mc.options.getFov().getValue()), tanY = (float) Math.tan(fovY / 2f), maxB = VolConfig.renderChunks * 16f;
      float near = (float) Math.min(48.0, Math.max(4.0, vanillaB * 0.25)), far = Math.max(2048f, maxB * 1.25f);
      Matrix4f proj = new Matrix4f().perspective(fovY, aspect, near, far), view = new Matrix4f().rotation(camera.getRotation().conjugate(new Quaternionf()));
      float[] mvp = new float[16]; proj.mul(view, new Matrix4f()).get(mvp);
      double dd = ((mc.world.getTimeOfDay() / 24000.0) % 1.0 - 0.25 + 1.0) % 1.0, ang = (dd * 2.0 + (0.5 - Math.cos(dd * Math.PI) / 2.0)) / 3.0;
      float day = (float) Math.max(0.1, Math.min(1.0, Math.cos(ang * Math.PI * 2) * 2 + 0.5));
      double th = ang * Math.PI * 2; float sx = (float) -Math.sin(th), sy = (float) Math.cos(th), sz = 0.2f, sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz); float[] sun = {sx / sl, sy / sl, sz / sl};   // arah KE matahari

      boolean shadowOn = VolConfig.shadows && VolConfig.lighting && !low && VolConfig.shadowChunks > 0 && backend.wantsMeshes() && sun[1] > 0.05f;
      float[] lightMvp = null, shadowP = {1f, 1f, 1f, 0f}; double R = Math.min(VolConfig.shadowChunks, VolConfig.renderChunks) * 16.0, zExt = R + 700.0; int size = VolConfig.shadowRes;
      if (shadowOn) {
        try {
          shadow.ensure(size); double texel = 2 * R / size;
          Matrix4d rd = new Matrix4d().lookAlong(-sun[0], -sun[1], -sun[2], 0, 0, 1); Vector3d p = rd.transformPosition(new Vector3d(camX, camY, camZ));
          double dx = p.x - Math.round(p.x / texel) * texel, dy = p.y - Math.round(p.y / texel) * texel;   // snap ke grid texel supaya bayangan tidak berkedip saat kamera bergerak
          Matrix4f rf = new Matrix4f().lookAlong(-sun[0], -sun[1], -sun[2], 0, 0, 1);
          Matrix4f lm = new Matrix4f().ortho((float) -R, (float) R, (float) -R, (float) R, (float) -zExt, (float) zExt).translate((float) dx, (float) dy, 0f).mul(rf);
          lightMvp = new float[16]; lm.get(lightMvp);
          shadowP = new float[]{size, (float) texel, (float) (2 * zExt), (float) Math.min(1.0, (sun[1] - 0.05) * 4.0) * 0.55f};
        } catch (Throwable e) { VolConfig.shadows = false; shadowOn = false; lightMvp = null; VolTraceClient.LOGGER.warn("bayangan dimatikan: {}", e.toString()); }
      }
      float[] opt = {VolConfig.textures ? 1f : 0f, VolConfig.lighting ? 1f : 0f, shadowOn ? 1f : 0f, VolConfig.fog ? 1f : 0f};
      Frame f = new Frame(mvp, camX, camY, camZ, maxB * 0.55f, maxB, new float[]{0.72f * day, 0.82f * day, day}, day, t, view, tanY * aspect, tanY, vanillaB, maxB,
        sun, lightMvp, shadowP, opt, false, shadowOn ? shadow.depthTex() : shadow.dummyTex());
      GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_LEQUAL); GL11.glDepthMask(true); GL11.glDisable(GL11.GL_CULL_FACE); GL11.glDisable(GL11.GL_BLEND); GL11.glDisable(GL11.GL_SCISSOR_TEST);

      int casters = 0;
      if (shadowOn) {   // pass bayangan: section LOD terlihat dalam radius bayangan digambar depth-only dari arah matahari
        List<Key> cs = new ArrayList<>();
        for (Key k : visible) { double ks = 32.0 * (1L << k.level()), ddx = k.sx() * ks + ks / 2 - camX, ddz = k.sz() * ks + ks / 2 - camZ; if (Math.hypot(ddx, ddz) < R + ks) cs.add(k); }
        casters = cs.size(); shadow.begin(); backend.draw(f.asShadow(lightMvp), cs); shadow.end(fbo);
      }
      target.ensure(vpt[2], vpt[3]); target.begin();
      backend.draw(f, visible);
      target.end(fbo, mode, clr);
      diag(post, fbo, vpt, mode, casters);
    } catch (Throwable e) { fallback(e); }
    finally { snap.restore(); }
  }
  static void diag(boolean post, int fbo, int[] vpt, int mode, int casters) {
    if (!VolConfig.debug) return; long n = System.currentTimeMillis(); if (n - lastDiag < 4000) return; lastDiag = n;
    VolTraceClient.LOGGER.info("[diag] jalur={} mode={} drawFbo={} viewport={}x{} terlihat={} diGPU={} tile={} caster={} pack={} backend={}", post ? "pasca-Iris" : "vanilla", mode, fbo, vpt[2], vpt[3], visible.size(), uploaded.size(), TileAtlas.count(), casters, IrisCompat.packActive(), backend.name());
  }
  /** Backend gagal -> turun otomatis: Indirect -> Classic -> CPU -> mati. */
  static void fallback(Throwable e) {
    VolTraceClient.LOGGER.error("backend gagal", e);
    String cur = backend == null ? VolConfig.backend : backend.name().toLowerCase();
    try { if (backend != null) backend.close(); } catch (Throwable ignored) {}
    backend = null; uploaded.clear(); ready.clear(); building.clear();
    if (cur.startsWith("indirect") || cur.equals("auto")) VolConfig.backend = "classic"; else if (cur.startsWith("classic")) VolConfig.backend = "cpu"; else VolConfig.enabled = false;
  }
  public static void setBackend(String name) { VolConfig.backend = name; try { if (backend != null) backend.close(); } catch (Throwable ignored) {} backend = null; uploaded.clear(); ready.clear(); }
  public static String status() {
    LodOctree t = tree;
    return "jalur=" + (usePost() ? "pasca-shader" : "vanilla") + (IrisCompat.packActive() ? " (shader pack aktif)" : "") + ", backend=" + (backend == null ? "-" : backend.name()) + ", jarak=" + VolConfig.renderChunks + " chunk, bayangan=" + VolConfig.shadowChunks
      + " chunk, section terlihat=" + visible.size() + ", di GPU=" + uploaded.size() + ", tile tekstur=" + TileAtlas.count() + ", kolom di RAM=" + (t == null ? 0 : t.columnCount()) + ", chunk di LOD=" + (t == null ? 0 : t.chunkCount());
  }
}
