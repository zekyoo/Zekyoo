package com.voltrace.client.core;
import com.voltrace.client.VolTraceClient; import com.voltrace.client.config.VolConfig;
import com.voltrace.common.world.LodOctree;
import net.minecraft.client.MinecraftClient; import net.minecraft.registry.RegistryKey; import net.minecraft.server.MinecraftServer; import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World; import net.minecraft.world.chunk.Chunk; import net.minecraft.world.chunk.ChunkStatus;
import java.util.concurrent.atomic.AtomicBoolean;
/** Singleplayer: minta world generator server membuat chunk ASLI (status FEATURES, spiral dari pemain) dalam batas waktu per tick, lalu salin ke LOD.
 *  Detail penuh (pohon, gua, struktur) tapi chunk tersimpan ke save dunia, jadi radius default dibuat kecil (32). Area lebih jauh ditangani TerrainSynth. */
final class LodGenerator {
  private static int ring = 1, idx = 0, cx0 = Integer.MIN_VALUE, cz0; private static LodOctree last; private static final AtomicBoolean pending = new AtomicBoolean();
  static void tick(MinecraftClient mc, LodOctree tree) {
    if (!VolConfig.generate || VolConfig.genChunks <= 0 || mc.world == null || mc.player == null) return;
    MinecraftServer srv = mc.getServer(); if (srv == null || !pending.compareAndSet(false, true)) return;
    RegistryKey<World> dim = mc.world.getRegistryKey(); int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
    srv.execute(() -> { try { step(srv, dim, tree, pcx, pcz); } catch (Throwable t) { VolTraceClient.LOGGER.warn("generator: {}", t.toString()); } finally { pending.set(false); } });
  }
  static int[] ringCell(int r, int i) {
    int side = 2 * r, s = i / side, o = i % side;
    return switch (s) { case 0 -> new int[]{-r + o, -r}; case 1 -> new int[]{r, -r + o}; case 2 -> new int[]{r - o, r}; default -> new int[]{-r, r - o}; };
  }
  private static void step(MinecraftServer srv, RegistryKey<World> dim, LodOctree tree, int pcx, int pcz) {
    if (tree != last || cx0 == Integer.MIN_VALUE || Math.abs(pcx - cx0) > 8 || Math.abs(pcz - cz0) > 8) { last = tree; cx0 = pcx; cz0 = pcz; ring = 1; idx = 0; }
    ServerWorld w = srv.getWorld(dim); if (w == null) return;
    int gen = 0, checks = 0, max = Math.min(VolConfig.genChunks, VolConfig.renderChunks); long t0 = System.nanoTime(), budget = VolConfig.genMs * 1_000_000L;
    while (checks < 4000 && ring <= max && (gen == 0 || System.nanoTime() - t0 < budget)) {   // minimal 1 chunk/tick, sisanya sampai anggaran waktu habis
      int[] c = ringCell(ring, idx); int x = cx0 + c[0], z = cz0 + c[1]; if (++idx >= 8 * ring) { idx = 0; ring++; } checks++;
      if (tree.hasChunk(x, z)) continue;
      Chunk ch = w.getChunk(x, z, ChunkStatus.FEATURES, true); gen++;
      LodManager.exec.execute(() -> { try { ChunkIngest.run(tree, ch); } catch (Throwable e) { VolTraceClient.LOGGER.warn("ingest gen: {}", e.toString()); } });
    }
  }
}
