package com.voltrace.client.core.rendering;
import com.voltrace.common.world.LodOctree.Key;
import org.lwjgl.opengl.*; import java.util.*;
/** Gaya Voxy: semua mesh di satu arena VBO, seluruh LOD digambar dengan SATU glMultiDrawArraysIndirect (butuh GL 4.3). */
public final class IndirectBackend implements RenderBackend {
  private static final long MAX_CAP = 1L << 30;
  private static final class Arena {
    long cap; final TreeMap<Long, Long> free = new TreeMap<>();
    Arena(long cap) { this.cap = cap; free.put(0L, cap); }
    long alloc(long n) { for (var e : free.entrySet()) if (e.getValue() >= n) { long off = e.getKey(), sz = e.getValue(); free.remove(off); if (sz > n) free.put(off + n, sz - n); return off; } return -1; }
    void release(long off, long n) {
      Long nx = free.remove(off + n); if (nx != null) n += nx;
      var lo = free.floorEntry(off); if (lo != null && lo.getKey() + lo.getValue() == off) free.put(lo.getKey(), lo.getValue() + n); else free.put(off, n);
    }
    void grow(long nc) { release(cap, nc - cap); cap = nc; }
  }
  private final HashMap<Key, long[]> meshes = new HashMap<>(); // {byteOffset, vertexCount, byteSize}
  private Arena arena; private int prog, progS, vao, arenaBuf, secBuf, cmdBuf;
  public String name() { return "Indirect (GL4.3, Voxy-style)"; } public boolean wantsMeshes() { return true; }
  private void attribs() {
    GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arenaBuf);
    GL30.glVertexAttribIPointer(0, 1, GL11.GL_UNSIGNED_INT, 8, 0L); GL30.glVertexAttribIPointer(1, 1, GL11.GL_UNSIGNED_INT, 8, 4L);
  }
  public void init() {
    prog = Shaders.program(Shaders.vs(true), Shaders.fs(), "aPos", "aCol", "aSec"); progS = Shaders.program(Shaders.vs(true), Shaders.fsShadow(), "aPos", "aCol", "aSec");
    vao = GL30.glGenVertexArrays(); arenaBuf = GL15.glGenBuffers(); secBuf = GL15.glGenBuffers(); cmdBuf = GL15.glGenBuffers();
    arena = new Arena(64L << 20); GL30.glBindVertexArray(vao);
    GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arenaBuf); GL15.glBufferData(GL15.GL_ARRAY_BUFFER, arena.cap, GL15.GL_STATIC_DRAW);
    attribs(); GL20.glEnableVertexAttribArray(0); GL20.glEnableVertexAttribArray(1);
    GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, secBuf); GL20.glVertexAttribPointer(2, 4, GL11.GL_FLOAT, false, 16, 0L);
    GL20.glEnableVertexAttribArray(2); GL33.glVertexAttribDivisor(2, 1);
  }
  private boolean grow() {
    if (arena.cap >= MAX_CAP) return false; long nc = arena.cap * 2; int nb = GL15.glGenBuffers();
    GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, nb); GL15.glBufferData(GL31.GL_COPY_WRITE_BUFFER, nc, GL15.GL_STATIC_DRAW);
    GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, arenaBuf); GL31.glCopyBufferSubData(GL31.GL_COPY_READ_BUFFER, GL31.GL_COPY_WRITE_BUFFER, 0L, 0L, arena.cap);
    GL15.glDeleteBuffers(arenaBuf); arenaBuf = nb; arena.grow(nc);
    GL30.glBindVertexArray(vao); attribs(); return true;
  }
  public void upload(Key k, int[] m) {
    remove(k); if (m.length == 0) return;
    long bytes = m.length * 4L, off = arena.alloc(bytes);
    while (off < 0 && grow()) off = arena.alloc(bytes);
    if (off < 0) return; // VRAM arena penuh: section ini dilewati
    GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arenaBuf); GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, off, m);
    meshes.put(k, new long[]{off, m.length / 2, bytes});
  }
  public void remove(Key k) { long[] m = meshes.remove(k); if (m != null) arena.release(m[0], m[2]); }
  public void clear() { for (Key k : new ArrayList<>(meshes.keySet())) remove(k); }
  public void draw(Frame f, List<Key> keys) {
    int n = 0, cap = keys.size(); int[] cmd = new int[cap * 4]; float[] sec = new float[cap * 4];
    for (Key k : keys) { long[] m = meshes.get(k); if (m == null) continue;
      cmd[n * 4] = (int) m[1]; cmd[n * 4 + 1] = 1; cmd[n * 4 + 2] = (int) (m[0] / 8); cmd[n * 4 + 3] = n;
      float[] s = Frame.sec(k, f.cx(), f.cy(), f.cz()); System.arraycopy(s, 0, sec, n * 4, 4); n++; }
    if (n == 0) return;
    int p = f.shadowPass() ? progS : prog; GL20.glUseProgram(p); if (f.shadowPass()) Shaders.shadowUniforms(p, f); else Shaders.uniforms(p, f); GL30.glBindVertexArray(vao);
    GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, secBuf); GL15.glBufferData(GL15.GL_ARRAY_BUFFER, Arrays.copyOf(sec, n * 4), GL15.GL_STREAM_DRAW);
    GL15.glBindBuffer(GL40.GL_DRAW_INDIRECT_BUFFER, cmdBuf); GL15.glBufferData(GL40.GL_DRAW_INDIRECT_BUFFER, Arrays.copyOf(cmd, n * 4), GL15.GL_STREAM_DRAW);
    GL43.glMultiDrawArraysIndirect(GL11.GL_TRIANGLES, 0L, n, 0);
    GL15.glBindBuffer(GL40.GL_DRAW_INDIRECT_BUFFER, 0);
  }
  public void close() { if (prog != 0) { GL20.glDeleteProgram(prog); GL20.glDeleteProgram(progS); GL15.glDeleteBuffers(arenaBuf); GL15.glDeleteBuffers(secBuf); GL15.glDeleteBuffers(cmdBuf); GL30.glDeleteVertexArrays(vao); } }
}
