package com.voltrace.client.core.rendering;
import com.voltrace.client.compat.GpuInfo; import com.voltrace.client.config.VolConfig; import org.lwjgl.opengl.*;
/** Otomatis: GL4.3+ dan bukan mode kompatibilitas -> Indirect (gaya Voxy); selain itu Classic (GL3.2/GLES3, syarat minimum Minecraft sendiri, cocok untuk Android). CPU hanya cadangan/manual. */
public final class BackendSelector {
  public static RenderBackend select() {
    GpuInfo.init(); String p = VolConfig.backend.toLowerCase(); boolean ind = GL.getCapabilities().OpenGL43 && !GpuInfo.lowEnd();
    return switch (p) { case "cpu" -> new CpuBackend(); case "classic" -> new ClassicBackend(); default -> ind ? new IndirectBackend() : new ClassicBackend(); };
  }
}
