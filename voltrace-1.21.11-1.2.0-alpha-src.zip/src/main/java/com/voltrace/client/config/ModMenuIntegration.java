package com.voltrace.client.config;
import com.terraformersmc.modmenu.api.ConfigScreenFactory; import com.terraformersmc.modmenu.api.ModMenuApi;
/** Tombol konfigurasi di daftar mod Mod Menu. */
public final class ModMenuIntegration implements ModMenuApi {
  @Override public ConfigScreenFactory<?> getModConfigScreenFactory() { return parent -> new VolSettingsScreen(parent); }
}
