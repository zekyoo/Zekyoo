package com.voltrace.client.mixin.minecraft;
import com.voltrace.client.config.VolSettingsScreen;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.Drawable; import net.minecraft.client.gui.Element; import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.screen.option.OptionsScreen; import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At; import org.spongepowered.asm.mixin.injection.Inject; import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Menaruh tombol "VolTrace" di Options, Video Settings vanilla, dan layar Video Settings Sodium (dikenali lewat nama kelas, tanpa dependensi compile ke Sodium). */
@Mixin(Screen.class)
public abstract class MixinScreen {
  @Shadow protected abstract <T extends Element & Drawable & Selectable> T addDrawableChild(T child);
  @Inject(method = "init(Lnet/minecraft/client/MinecraftClient;II)V", at = @At("TAIL"), require = 0)
  private void voltrace$addButton(MinecraftClient client, int w, int h, CallbackInfo ci) {
    Screen self = (Screen) (Object) this; String n = self.getClass().getName(); int x;
    if (self instanceof OptionsScreen || self instanceof VideoOptionsScreen) x = 6;
    else if (n.startsWith("net.caffeinemc.mods.sodium.client.gui") && (n.contains("OptionsGUI") || n.contains("VideoSettings"))) x = w - 96;
    else return;
    addDrawableChild(ButtonWidget.builder(Text.literal("VolTrace"), b -> client.setScreen(new VolSettingsScreen(self))).dimensions(x, 6, 90, 20).build());
  }
}
