package com.voltrace.client.iris;
import com.voltrace.client.VolTraceClient;
import net.fabricmc.loader.api.FabricLoader;
import java.lang.reflect.Method;
/** Deteksi shader pack Iris lewat API publik Iris (refleksi, jadi tidak ada dependensi compile-time). */
public final class IrisCompat {
  private static boolean init; private static Object api; private static Method inUse;
  public static boolean packActive() {
    if (!init) { init = true;
      if (FabricLoader.getInstance().isModLoaded("iris")) {
        try { Class<?> c = Class.forName("net.irisshaders.iris.api.v0.IrisApi"); api = c.getMethod("getInstance").invoke(null); inUse = c.getMethod("isShaderPackInUse"); }
        catch (Throwable t) { VolTraceClient.LOGGER.warn("Iris terdeteksi tapi API-nya tidak bisa dibaca: {}", t.toString()); api = null; }
      } }
    if (api == null) return false;
    try { return (boolean) inUse.invoke(api); } catch (Throwable t) { return false; }
  }
}
