package com.voltrace.client;
import com.mojang.brigadier.CommandDispatcher; import com.mojang.brigadier.arguments.IntegerArgumentType; import com.mojang.brigadier.arguments.StringArgumentType;
import com.voltrace.client.compat.GpuInfo; import com.voltrace.client.config.VolConfig; import com.voltrace.client.config.VolSettingsScreen; import com.voltrace.client.core.LodManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager; import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient; import net.minecraft.text.Text;
import java.util.List;
public final class VolCommands {
  private static void say(FabricClientCommandSource s, String m) { s.sendFeedback(Text.literal(m)); }
  private static int pick(FabricClientCommandSource s, String what, String v, List<String> ok) { if (!ok.contains(v)) { say(s, "Pilih: " + String.join(" | ", ok)); return 0; } return 1; }
  public static void register(CommandDispatcher<FabricClientCommandSource> d) {
    var root = ClientCommandManager.literal("voltrace")
      .then(ClientCommandManager.literal("settings").executes(c -> { MinecraftClient mc = MinecraftClient.getInstance(); mc.send(() -> mc.setScreen(new VolSettingsScreen(null))); return 1; }))
      .then(ClientCommandManager.literal("status").executes(c -> { say(c.getSource(), LodManager.status()); return 1; }))
      .then(ClientCommandManager.literal("gpu").executes(c -> { say(c.getSource(), GpuInfo.summary()); return 1; }))
      .then(ClientCommandManager.literal("toggle").executes(c -> { VolConfig.enabled = !VolConfig.enabled; VolConfig.save(); say(c.getSource(), "VolTrace " + (VolConfig.enabled ? "aktif" : "mati")); return 1; }))
      .then(ClientCommandManager.literal("debug").executes(c -> { VolConfig.debug = !VolConfig.debug; VolConfig.save(); say(c.getSource(), "Log diagnostik " + (VolConfig.debug ? "aktif (lihat latest.log)" : "mati")); return 1; }))
      .then(ClientCommandManager.literal("reload").executes(c -> { LodManager.reloadTextures(); say(c.getSource(), "Tekstur blok dimuat ulang dari resource pack"); return 1; }))
      .then(ClientCommandManager.literal("distance").then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(2, VolConfig.MAX_CHUNKS)).executes(c -> {
        int v = VolConfig.setChunks(IntegerArgumentType.getInteger(c, "chunks")); VolConfig.save(); say(c.getSource(), "Jarak LOD = " + v + " chunk"); return 1; })))
      .then(ClientCommandManager.literal("shadow").then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(0, VolConfig.MAX_CHUNKS)).executes(c -> {
        int v = VolConfig.setShadowChunks(IntegerArgumentType.getInteger(c, "chunks")); VolConfig.save(); say(c.getSource(), "Radius bayangan = " + v + " chunk (0 = mati)"); return 1; })))
      .then(ClientCommandManager.literal("backend").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
        String n = StringArgumentType.getString(c, "name"); if (pick(c.getSource(), "backend", n, List.of("auto", "indirect", "classic", "cpu")) == 0) return 0;
        LodManager.setBackend(n); VolConfig.save(); say(c.getSource(), "Backend = " + n); return 1; })))
      .then(ClientCommandManager.literal("shader").then(ClientCommandManager.argument("mode", StringArgumentType.word()).executes(c -> {
        String m = StringArgumentType.getString(c, "mode"); if (pick(c.getSource(), "shader", m, List.of("auto", "post", "legacy")) == 0) return 0;
        VolConfig.shaderMode = m; VolConfig.save(); say(c.getSource(), "Mode shader = " + m); return 1; })))
      .then(ClientCommandManager.literal("compat").then(ClientCommandManager.argument("mode", StringArgumentType.word()).executes(c -> {
        String m = StringArgumentType.getString(c, "mode"); if (pick(c.getSource(), "compat", m, List.of("auto", "on", "off")) == 0) return 0;
        VolConfig.compat = m; VolConfig.save(); LodManager.setBackend(VolConfig.backend); LodManager.applyThreads(); say(c.getSource(), "Mode kompatibilitas (Android/GPU lemah) = " + m); return 1; })));
    var node = d.register(root); d.register(ClientCommandManager.literal("vt").redirect(node));
  }
}
