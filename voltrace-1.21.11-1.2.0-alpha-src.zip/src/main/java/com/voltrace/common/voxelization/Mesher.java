package com.voltrace.common.voxelization;
import com.voltrace.common.world.LodOctree; import com.voltrace.common.world.Section;
import java.util.Arrays;
/** Greedy mesher. Vertex = 2 int: a = x|y<<6|z<<12|face<<18|tileSisi<<21|flagTint<<29 (koordinat sel 0..32), b = warna RGB | tileAtas<<24. 6 vertex per quad. */
public final class Mesher {
  public static final int[] EMPTY = new int[0];
  public static int[] mesh(LodOctree t, LodOctree.Key k) {
    Section s = t.get(k); if (s == null || s.isEmpty()) return EMPTY;
    int[] out = new int[2048]; int n = 0; short[] mask = new short[1024]; int[] c = new int[3], p = new int[3];
    for (int face = 0; face < 6; face++) {
      int axis = face >> 1, dir = (face & 1) == 0 ? -1 : 1, ua = (axis + 1) % 3, va = (axis + 2) % 3;
      Section nb = t.get(new LodOctree.Key(k.level(), k.sx() + (axis == 0 ? dir : 0), k.sy() + (axis == 1 ? dir : 0), k.sz() + (axis == 2 ? dir : 0)));
      for (int slice = 0; slice < 32; slice++) {
        boolean any = false;
        for (int j = 0; j < 32; j++) for (int i = 0; i < 32; i++) {
          c[axis] = slice; c[ua] = i; c[va] = j; short v = s.at(c[0], c[1], c[2]), m = 0;
          if (v != 0) { int ns = slice + dir; short nv;
            if (ns >= 0 && ns < 32) { c[axis] = ns; nv = s.at(c[0], c[1], c[2]); }
            else { c[axis] = ns < 0 ? 31 : 0; nv = nb == null ? 0 : nb.at(c[0], c[1], c[2]); }
            if (nv == 0) m = v; }
          mask[j * 32 + i] = m; if (m != 0) any = true;
        }
        if (!any) continue;
        for (int j = 0; j < 32; j++) for (int i = 0; i < 32; ) {
          short v = mask[j * 32 + i]; if (v == 0) { i++; continue; }
          int w = 1; while (i + w < 32 && mask[j * 32 + i + w] == v) w++;
          int h = 1; outer: while (j + h < 32) { for (int q = 0; q < w; q++) if (mask[(j + h) * 32 + i + q] != v) break outer; h++; }
          for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) mask[(j + y) * 32 + i + x] = 0;
          if (n + 12 > out.length) out = Arrays.copyOf(out, out.length * 2);
          int plane = slice + (dir > 0 ? 1 : 0), rgb = t.palette.rgb(v), tl = t.palette.tiles(v), top = tl & 255, side = (tl >> 8) & 255, fl = (tl >> 16) & 3;
          int[] cu = {i, i + w, i + w, i}, cv = {j, j, j + h, j + h}, idx = {0, 1, 2, 0, 2, 3};
          for (int q : idx) { p[axis] = plane; p[ua] = cu[q]; p[va] = cv[q]; out[n++] = p[0] | p[1] << 6 | p[2] << 12 | face << 18 | side << 21 | fl << 29; out[n++] = rgb | top << 24; }
          i += w;
        }
      }
    }
    return Arrays.copyOf(out, n);
  }
}
