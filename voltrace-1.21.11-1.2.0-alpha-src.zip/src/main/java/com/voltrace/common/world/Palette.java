package com.voltrace.common.world;
import java.io.*; import java.nio.file.*; import java.util.concurrent.ConcurrentHashMap;
/** Palet entri voxel: warna RGB + info tekstur. tiles = tileAtas | tileSisi<<8 | flag<<16 (flag bit0 = atas ber-tint, bit1 = sisi ber-tint). */
public final class Palette {
  private final int[] colors = new int[65536], tiles = new int[65536];
  private final ConcurrentHashMap<Long, Short> ids = new ConcurrentHashMap<>();
  private int next = 1;
  private static long key(int rgb, int tl) { return ((long) tl << 24) | (rgb & 0xFFFFFFL); }
  public short idFor(int rgb) { return idFor(rgb, 0); }
  public synchronized short idFor(int rgb, int tl) {
    rgb &= 0xFFFFFF; long k = key(rgb, tl); Short s = ids.get(k); if (s != null) return s;
    if (next >= 65535) return 1;
    colors[next] = rgb; tiles[next] = tl; ids.put(k, (short) next); return (short) next++;
  }
  public int rgb(short id) { return colors[id & 0xFFFF]; }
  public int tiles(short id) { return tiles[id & 0xFFFF]; }
  public synchronized void save(Path p) {
    try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(p)))) {
      o.writeInt(-2); o.writeInt(next); for (int i = 1; i < next; i++) { o.writeInt(colors[i]); o.writeInt(tiles[i]); }
    } catch (IOException e) { e.printStackTrace(); }
  }
  public synchronized void load(Path p) {
    if (!Files.exists(p)) return;
    try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(p)))) {
      int n = in.readInt();
      if (n == -2) { n = in.readInt(); for (int i = 1; i < n; i++) { colors[i] = in.readInt(); tiles[i] = in.readInt(); ids.put(key(colors[i], tiles[i]), (short) i); } }
      else { for (int i = 1; i < n; i++) { colors[i] = in.readInt(); tiles[i] = 0; ids.put(key(colors[i], 0), (short) i); } }   // format lama (tanpa tekstur)
      next = n;
    } catch (IOException e) { e.printStackTrace(); }
  }
}
