package com.voltrace.common.world;
import java.util.Arrays;
/** 32^3 sel. Nilai 0 = udara, selain itu = id palet warna. Seragam (semua sama) disimpan tanpa array. */
public final class Section {
  public static final int N = 32, VOL = N * N * N;
  public volatile short[] cells; public volatile short uniform; public volatile int version;
  public short at(int x, int y, int z) { short[] c = cells; return c == null ? uniform : c[(y * N + z) * N + x]; }
  public synchronized void set(int x, int y, int z, short v) {
    if (cells == null) { if (v == uniform) return; short[] a = new short[VOL]; Arrays.fill(a, uniform); cells = a; }
    cells[(y * N + z) * N + x] = v;
  }
  public synchronized void compact() {
    short[] c = cells; if (c == null) return; short f = c[0];
    for (short s : c) if (s != f) return;
    uniform = f; cells = null;
  }
  public boolean isEmpty() { return cells == null && uniform == 0; }
  public int bytes() { return cells == null ? 16 : VOL * 2; }
}
