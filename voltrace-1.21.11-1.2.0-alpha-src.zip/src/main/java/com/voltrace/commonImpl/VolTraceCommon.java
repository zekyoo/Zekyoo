package com.voltrace.commonImpl;
import net.fabricmc.api.ModInitializer;
/** Entrypoint "main" (seperti Voxy: me.cortex.voxy.commonImpl.VoxyCommon). Logika render ada di sisi client. */
public class VolTraceCommon implements ModInitializer {
  public static boolean isAvailable() { return true; }
  @Override public void onInitialize() {}
}
